
let a = 5
let b = 4
let natija = a ** b
console.log(natija);


let c = 22
let d = 4
let natija2 = c % d
console.log(natija2);

let f = 125
let yuzi = f ** 2
let perimetr = f * 4
console.log(yuzi, perimetr);
